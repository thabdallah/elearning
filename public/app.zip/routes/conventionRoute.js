var express=require('express');
const conventionService = require('../services/conventionService');
var router=express.Router();

router.use(function(req, res, next){
    if(req.session.user.droit=='admin'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
});


router.get('/list/:viewMode/:intitule?', async (req, res)=>{

    /*if(req.session.user.droit!='admin'){
        
    }else{

    }*/

    var conventions= await conventionService.list();
    var convention={};
    if(req.params.viewMode=='EDIT'){
        var u=await conventionService.getByIntitule(req.params.intitule);
        convention= u.shift()
    }


    res.render('administration/conventionList',{
        conventions: conventions,
        convention: convention,
        viewMode: req.params.viewMode,
        result: {error: req.flash('error'), success: req.flash('success')}
    });
});

router.post('/save', async function(req, res){
    const {intitule, couverture_consultation, couverture_produit, couverture_examen, couverture_soins, couverture_hospitalisation}=req.body;

    if(await conventionService.isConventionExist(intitule)> 0){
        req.flash('error', 'Le intitule '+intitule+' existe déja');
        return res.redirect('/convention/list/CREATE')
    }

    if(couverture_consultation < 0 || couverture_consultation > 100 || couverture_examen < 0 || couverture_examen > 100 || couverture_produit < 0 || couverture_produit > 100 || couverture_soins < 0 || couverture_soins > 100 || couverture_hospitalisation < 0 || couverture_hospitalisation > 100){
        req.flash('error', 'La couverture doit être comprise entre 0 et 100');
        return res.redirect('/convention/list/CREATE')
    }

    var convention= await conventionService.mapConvention(intitule, couverture_consultation, couverture_produit, couverture_examen, couverture_soins, couverture_hospitalisation);

    convention.who_done="test"//req.session.convention.intitule;
    convention.when_done=new Date();

    const rs=await conventionService.add(convention);

    if(rs.rowCount==1){
        req.flash('success', "Convention ajouté avec success");
        res.redirect('/convention/list/CREATE');
    }else{
        req.flash('error', "Convention non ajouté");
        res.redirect('/convention/list/CREATE');
    }
   
});

router.post('/edit', async function(req, res){
    const {intitule, couverture_consultation, couverture_produit, couverture_examen, couverture_soins, couverture_hospitalisation}=req.body;


    if(couverture_consultation < 0 || couverture_consultation > 100 || couverture_examen < 0 || couverture_examen > 100 || couverture_produit < 0 || couverture_produit > 100 || couverture_soins < 0 || couverture_soins > 100 || couverture_hospitalisation < 0 || couverture_hospitalisation > 100){
        req.flash('error', 'La couverture doit être comprise entre 0 et 100');
        return res.redirect('/convention/list/EDIT/'+intitule)
    }

    var convention= await conventionService.mapConvention(intitule, couverture_consultation, couverture_produit, couverture_examen, couverture_soins, couverture_hospitalisation);

    convention.who_done=req.session.user.login;
    convention.when_done=new Date();

    const rs=await conventionService.edit(convention);
    if(rs.rowCount==1){
        req.flash('success', "Convention modifier avec");
        res.redirect('/convention/list/CREATE');
    }else{
        req.flash('error', "Convention non modifier");
        res.redirect('/convention/list/CREATE');
    }
   
});



module.exports=router;