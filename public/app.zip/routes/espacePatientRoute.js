var express=require('express');
const espacePatientService = require('../services/espacePatientService');
var router=express.Router();

router.get('/:id', async (req, res)=>{
    var patient= await espacePatientService.getPatientById(req.params.id);
    var conventions= await espacePatientService.getConvention();
    var medecins=await espacePatientService.getAllMedecin();
    var consultations=await espacePatientService.getAllConsultation();
    var autresService=await espacePatientService.getAllOtherProduit();
    var consultationsTemp=await espacePatientService.getTempConsultationByPatient(req.params.id);
    var autreServiceTemp=await espacePatientService.getTempAutresServiceByPatient(req.params.id);
    var total=getMontantTotal(autreServiceTemp);
    req.
    
    res.render('traitement/espacePatient',{
        patient: patient.shift(),
        conventions: conventions,
        medecins: medecins,
        consultations: consultations,
        consultationsTemp: consultationsTemp,
        autresService: autresService,
        autreServiceTemp: autreServiceTemp,
        total: total,
        result: {error: req.flash('error'), success: req.flash('success')}
    });

});

router.post('/save', (req, res, next) => {
    if(req.session.user.droit=='caissier'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
  });

router.post('/save', async(req, res)=>{
        const {patient, produit, medecin, convention, quantite}=req.body;
        var numero_carnet=req.body.numero_carnet;
        var autre_info_convention=req.body.autre_info_convention;
        if(convention==1000){
            numero_carnet=0;
            autre_info_convention=0;
        }

        if(convention!=1000 && (numero_carnet==0 || numero_carnet==null)){
            req.flash('error', "Numero carnet doit être different de zero si prise en charge");
            res.redirect('/espace/'+patient);
        }
        else if(quantite<1 || quantite == null){
            req.flash('error', "La quantite doit être superieur à ZERO");
            res.redirect('/espace/'+patient);
        }else{
            var conv=await espacePatientService.getConventionById(convention);
        var convObj=conv.shift();
        var prod=await espacePatientService.getProduitById(produit);
        var prodObj=prod.shift();
        var type_operation=prodObj.type;
        var intituleProd=prodObj.intitule;
        var couverture=getCouvertureConvention(convObj, type_operation);
        var who_done=req.session.user.login;
        var when_done=new Date();
        var montant_operation=getMontatnOperation(prodObj,couverture);
        var montant_convention=(parseInt(montant_operation) * parseInt(couverture))/100;
        var montant_patient=parseInt(montant_operation) - parseInt(montant_convention);
        var montant_total_operation=parseInt(montant_operation) * parseInt(quantite);
        var montant_total_convention=parseInt(montant_convention) * parseInt(quantite);
        var montant_total_patient=parseInt(montant_patient) * parseInt(quantite);
        const rs=await espacePatientService.save(patient, produit, medecin, convention, numero_carnet, autre_info_convention, who_done, when_done, quantite,couverture,montant_operation,montant_convention,montant_patient,montant_total_operation,montant_total_convention,montant_total_patient,type_operation,intituleProd,convObj.intitule);
        if(rs.rowCount==1){
            req.flash('success', "operation ajouté avec success");
            res.redirect('/espace/'+patient);
        }else{
            req.flash('error', "operation non ajouté");
            res.redirect('/espace/'+patient);
        }
        }
        
        });

router.get('/valider/:type_produit/:patient', (req, res, next) => {
    if(req.session.user.droit=='caissier'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
});

router.get('/valider/:type_produit/:patient', async(req, res)=>{
    var rs=await espacePatientService.validerOperation(req.session.user.login,new Date(),req.params.type_produit,req.params.patient);
   // (req.params.type_produit, req.params.patient);
    if(rs==1){
        req.flash('success', "operation valider avec success");
        res.redirect('/espace/facture/'+req.params.patient);
    }else{
        req.flash('error', "operation non valider");
        res.redirect('/espace/'+req.params.patient);
    }
});


router.get('/supprimer/:id/:patient', (req, res, next) => {
    if(req.session.user.droit=='caissier'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
});

router.get('/supprimer/:id/:patient', async(req, res)=>{
    var rs=await espacePatientService.supprimerOp(req.params.id);
    if(rs.rowCount==1){
        req.flash('success', "operation supprimer avec success");
        res.redirect('/espace/'+req.params.patient);
    }else{
        req.flash('error', "operation non supprimer");
        res.redirect('/espace/'+req.params.patient);
    }
});

router.get('/facture/:patient', (req, res, next) => {
    if(req.session.user.droit=='caissier'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
});



router.get('/facture/:patient', async(req, res)=>{
    var factures=await espacePatientService.getFactureByPatient(req.params.patient);
    var patient= await espacePatientService.getPatientById(req.params.patient);
    res.render('traitement/facturePatient',{
        factures: factures,
        patient: patient.shift()
    })
});

function getMontantTotal(lignes){
    var total=0;
    for (let index = 0; index < lignes.length; index++) {
        total = parseInt(total) + parseInt(lignes[index].montant_total_patient);
    }
    return total;
}

function getCouvertureConvention(convention, intituleProduit){
    if(intituleProduit='CONSULTATION'){
        return convention.couverture_consultation;
    }
    if(intituleProduit='EXAMEN'){
        return couverture=convention.couverture_examen;
    }
    if(intituleProduit='PRODUIT'){
        return couverture=convention.couverture_produit;
    }
    if(intituleProduit='SOINS'){
        return couverture=convention.couverture_soins;
    }
    if(intituleProduit='HOSPITALISATION'){
        return couverture=convention.couverture_hospitalisation;
    }
}


function getMontatnOperation(produit, couverture){


    if(couverture==0){
        return produit.prix_sans_convention;
    }else{
        return produit.prix_avec_convention;
    }
}
module.exports=router;