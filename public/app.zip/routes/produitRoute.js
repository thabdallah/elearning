var express=require('express');
const produitService = require('../services/produitService');
var router=express.Router();


router.use(function(req, res, next){
    if(req.session.user.droit=='admin'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
});


router.get('/list/:viewMode/:id?', async (req, res)=>{
    var produits= await produitService.list();
    var produit={};
    if(req.params.viewMode=='EDIT'){
        var u=await produitService.getById(req.params.id);
        produit= u.shift()
    }


    res.render('administration/produitList',{
        produits: produits,
        produit: produit,
        viewMode: req.params.viewMode,
        result: {error: req.flash('error'), success: req.flash('success')}
    });
});

router.post('/save', async function(req, res){
    const {intitule, prix_sans_convention, prix_avec_convention, type, who_done, when_done}=req.body;

    if(await produitService.isProduitExist(intitule)> 0){
        req.flash('error', 'Un produit avec intitule '+intitule+' existe déja');
        return res.redirect('/produit/list/CREATE')
    }

    var produit= await produitService.mapProduit(intitule, prix_sans_convention, prix_avec_convention, type, who_done, when_done);

    produit.who_done=req.session.user.login;
    produit.when_done=new Date();

    const rs=await produitService.add(produit);

    if(rs.rowCount==1){
        req.flash('success', "produit ajouté avec success");
        res.redirect('/produit/list/CREATE');
    }else{
        req.flash('error', "produit non ajouté");
        res.redirect('/produit/list/CREATE');
    }
   
});

router.post('/edit', async function(req, res){
    const {id, intitule, prix_sans_convention, prix_avec_convention, type, who_done, when_done}=req.body;

    var produit= await produitService.mapProduit(intitule, prix_sans_convention, prix_avec_convention, type, who_done, when_done);

    produit.who_done=req.session.user.login;
    produit.when_done=new Date();
    produit.id=id;

    const rs=await produitService.edit(produit);
    if(rs.rowCount==1){
        req.flash('success', "produit modifier avec");
        res.redirect('/produit/list/CREATE');
    }else{
        req.flash('error', "produit non modifier");
        res.redirect('/produit/list/CREATE');
    }
   
});



module.exports=router;