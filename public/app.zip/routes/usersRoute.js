var express=require('express');
const usersService = require('../services/usersServices');
var router=express.Router();



router.use(function(req, res, next){
    if(req.session.user.droit=='admin'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
});


router.get('/list/:viewMode/:login?', async (req, res)=>{
    var users= await usersService.list();
    var user={};

    if(req.params.viewMode=='EDIT'){
        var u=await usersService.getByLogin(req.params.login);
        user= u.shift()
    }


    res.render('administration/userList',{
        users: users,
        user: user,
        viewMode: req.params.viewMode,
        result: {error: req.flash('error'), success: req.flash('success')}
    });
});

router.post('/save', async function(req, res){
    const {nom_prenom,login,droit,telephone, type_medecin}=req.body;

    if(await usersService.isUserExist(login)> 0){
        req.flash('error', 'Le login '+login+' existe déja');
        return res.redirect('/users/list/CREATE')
    }
    if(droit=='medecin' && (type_medecin=='' || null==type_medecin)){
        req.flash('error', 'Veullez choisir un type medecin pour les profils medecins');
        return res.redirect('/users/list/CREATE')
    }
    

    var user= await usersService.mapUser(nom_prenom,login,droit,telephone, type_medecin);

    user.who_done=req.session.user.login;
    user.when_done=new Date();
    if(droit!='medecin'){
        user.type_medecin='';
    }
    const rs=await usersService.add(user);

    if(rs.rowCount==1){
        req.flash('success', "Utilisateur ajouté avec success");
        res.redirect('/users/list/CREATE');
    }else{
        req.flash('error', "Utilisateur non ajouté");
        res.redirect('/users/list/CREATE');
    }
   
});

router.post('/edit', async function(req, res){
    const {nom_prenom,login,droit,telephone, type_medecin}=req.body;


    if(droit=='medecin' && (type_medecin=='' || null==type_medecin)){
        req.flash('error', 'Veullez choisir un type medecin pour les profils medecins');
        return res.redirect('/users/list/CREATE')
    }
   
    var user=await usersService.mapUser(nom_prenom,login,droit,telephone, type_medecin);
    if(droit!='medecin'){
        user.type_medecin='';
    }
   


    user.who_done=req.session.user.login;
    user.when_done=new Date();

    const rs=await usersService.edit(user);
    if(rs.rowCount==1){
        req.flash('success', "Utilisateur modifier avec");
        res.redirect('/users/list/CREATE');
    }else{
        req.flash('error', "Utilisateur non modifier");
        res.redirect('/users/list/CREATE');
    }
   
});

router.get('/init/:login', async (req, res)=>{
    await usersService.init(req.params.login);
    req.flash('success', 'Mot de passe de utilisateur '+req.params.login+' effectué avec success');
    return res.redirect('/users/list/CREATE');
});


router.get('/change-etat/:login', async (req, res)=>{
    await usersService.setEtat(req.params.login);
    req.flash('success', 'Etat de utilisateur '+req.params.login+' changé avec success');
    return res.redirect('/users/list/CREATE');
});



router.get('/user-auth', async (req, res)=>{
    return res.send(req.session.user);
});




module.exports=router;