var express=require('express');
const patientService = require('../services/patientService');
const usersService=require('../services/usersServices');
var router=express.Router();



router.get('/list/:viewMode/:id?', async (req, res)=>{
    var patients= await patientService.list();
    var factures= await patientService.getFactureByUser(req.session.user.login);
    montantToday=getMontantTodayFature(factures);
    var patient={};
    if(req.params.viewMode=='EDIT'){
        var u=await patientService.getById(req.params.id);
        patient= u.shift()
    }


    res.render('traitement/patientList',{
        patients: patients,
        patient: patient,
        montantToday: montantToday,
        viewMode: req.params.viewMode,
        result: {error: req.flash('error'), success: req.flash('success')}
    });
});

router.get('/situation-jour', (req, res, next) => {
    if(req.session.user.droit=='caissier'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
  });
router.get('/situation-jour', async (req, res)=>{
    var facts= await patientService.getFactureByUser(req.session.user.login);
    montantToday=getMontantTodayFature(facts);
    factures=getFactureToday(facts);
   
    res.render('traitement/situationJour',{
        factures: factures,
        montantToday: montantToday
        });
});


router.get('/form-situation', (req, res, next) => {
    if(req.session.user.droit=='admin'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
  });

router.get('/form-situation', async (req, res)=>{
    var users=await usersService.list();

    res.render('traitement/situationForm',{
        users: users,
        result: {error: req.flash('error'), success: req.flash('success')}
        });
});


router.post('/recherche-situation', (req, res, next) => {
    if(req.session.user.droit=='admin'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
  });

router.post('/recherche-situation', async (req, res)=>{
    var listeUsers=await usersService.list();
    const{users, operation, date_debut, date_fin}=req.body;
    var rs;
    if((date_debut=='' || date_debut==null) || (date_fin=='' || date_fin==null)){
        req.flash('error', 'Veuillez selectionnez les dates');
        return res.redirect('/patient/form-situation');
    }else{
        //console.log(date_debut);
        
        dd=new Date(date_debut);
        //console.log(dd);
        df=new Date(date_fin);
        if(date_debut==date_fin){
            var facts= await patientService.getFactureByUser(users);
            rs=getFactureByDate(facts, dd);
        }else{
            rs=await patientService.situation(dd,df,users);
        }

       total=getMontantFature(rs);
        res.render('traitement/situationForm',{
            users: listeUsers,
            resultats: rs,
            total: total
            });
    }
    
});

router.post('/save', async function(req, res){
    const {nom_prenom, telephone, adresse, situation, age, sexe}=req.body;

    if(await patientService.isPatientExist(telephone)> 0){
        req.flash('error', 'Le patient avec numero telephone '+telephone+' existe déja');
        return res.redirect('/patient/list/CREATE')
    }

    var patient= await patientService.mapPatient(nom_prenom, telephone, adresse, situation, age, sexe);

    patient.who_done=req.session.user.login;
    patient.when_done=new Date();

    const rs=await patientService.add(patient);

    if(rs.rowCount==1){
        req.flash('success', "patient ajouté avec success");
        res.redirect('/patient/list/CREATE');
    }else{
        req.flash('error', "patient non ajouté");
        res.redirect('/patient/list/CREATE');
    }
   
});

router.post('/edit', async function(req, res){
    const {id, nom_prenom, telephone, adresse, situation, age, sexe}=req.body;

    var patient= await patientService.mapPatient(nom_prenom, telephone, adresse, situation, age, sexe);

    patient.who_done=req.session.user.login;
    patient.when_done=new Date();
    patient.id=id;

    const rs=await patientService.edit(patient);
    if(rs.rowCount==1){
        req.flash('success', "patient modifier avec");
        res.redirect('/patient/list/CREATE');
    }else{
        req.flash('error', "patient non modifier");
        res.redirect('/patient/list/CREATE');
    }
   
});


function getMontantTodayFature(factures){
    var facts=0;
    for (let index = 0; index < factures.length; index++) {
       if(factures[index].when_done.toISOString().slice(0, 10)==new Date().toISOString().slice(0, 10)){
            facts=parseInt(facts) + parseInt(factures[index].montant_total_patient);
       }
    }
    return facts;
}

function getMontantFature(factures){
    var facts=0;
    for (let index = 0; index < factures.length; index++) {
            facts=parseInt(facts) + parseInt(factures[index].montant_total_patient);
    }
    return facts;
}

function getFactureToday(factures){
    var facts=[];
    for (let index = 0; index < factures.length; index++) {
       if(factures[index].when_done.toISOString().slice(0, 10)==new Date().toISOString().slice(0, 10)){
        facts.push(factures[index]);
       }
    }
    return facts;
}

function getFactureByDate(factures, dt){
    var facts=[];
    //console.log(dt);
    for (let index = 0; index < factures.length; index++) {
       if(factures[index].when_done.toISOString().slice(0, 10)==dt.toISOString().slice(0, 10)){
        facts.push(factures[index]);
       }
    }
    return facts;
}


module.exports=router;