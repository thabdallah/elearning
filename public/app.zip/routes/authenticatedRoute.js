var express=require('express');
const usersService = require('./../services/usersServices');
var router=express.Router();



router.get('/login', (req, res)=>{
    res.render('login',{
        result: {error: req.flash('error'), success: req.flash('success')}
    });
});

router.get('/logout', function(req, res){
    req.session.destroy(function(){
        //req.flash("success", "Vous êtes deconnecter.......");
            return res.redirect("/login");
    });
});

router.post('/login', async (req, res)=>{
    const {login, password}=req.body;
    if(!login || !password){
        req.flash("error", "Veuillez bien remplir le formulaire")
        return res.redirect('/login');
    }else{
        var user=await usersService.isUserCanLogin(login, password);
        if(user.length==1){
            u=user.shift();
            req.session.user={login: u.login, droit: u.droit, nom_prenom: u.nom_prenom};
                return res.redirect('/');
        }else{
            req.flash("error", "Login et/ou mot de passe incorrect");
            return res.redirect("/login");
        }
    }
});



router.get('/change-pass-form', async (req, res)=>{
    return res.render('traitement/changePass',{
        result: {error: req.flash('error'), success: req.flash('success')}
    });
});

router.post('/change-password', async (req, res)=>{

    const {old, neww, renew} = req.body;

    sessionUser=req.session.user.login;
    var userResult=await usersService.getByLogin(sessionUser);
    user=userResult.shift();

    if(old!=user.passe){
        req.flash('error', "Ancien mot de passe incorrect");
        res.redirect('/users/change-pass-form');
    }else{
        if(neww!=renew){
            req.flash('error', "Les 02 mot de passe ne sont pas les memes");
            res.redirect('/users/change-pass-form');
        }else{
            var rs=await usersService.changePassword(sessionUser, neww);
            if(rs.rowCount==1){
                req.flash('success', "Mot de passe changer avec success");
                return res.redirect('/patient/list/CREATE');
            }else{
                req.flash('error', "Erreur changement mot de passe");
                return res.redirect('/patient/list/CREATE');
            }
            
        }

        
    }

    
});






module.exports=router;