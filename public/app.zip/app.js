var express=require('express');
const app=express();
const cors=require('cors');
const users=require('./routes/usersRoute');
const convention=require('./routes/conventionRoute');
const patient=require('./routes/patientRoute');
const produit=require('./routes/produitRoute');
const espacePatient=require('./routes/espacePatientRoute');
const flash=require('connect-flash');
const session=require('express-session');
const cookieParser=require('cookie-parser');
const bodyParser=require('body-parser');
const authenticated=require('./routes/authenticatedRoute');
const indexSerivce=require('./services/indexService');


//const port=9014;
/*
var corsOptions = {
    origin: 'http://localhost:4000',
    optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
  }
  app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    res.header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Credentials', true);
    next();
});*/
app.set('view engine', 'twig');
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}))
//app.use(cors(corsOptions));
//app.use('/bootstrap', express.static('./node_modules/bootstrap/'));
app.set('views', './views');
app.use(cookieParser());
//app.use(session({secret: "Your secret key"}));
//app.use(cookieParser('secret'));
/*app.use(session({
    cookie: { maxAge: 60000 },
   // store: sessionStore,
    saveUninitialized: true,
    resave: 'true',
    secret: 'secret'
}));
*/

const oneDay = 1000 * 60 * 60 * 24;
app.use(session({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767klll",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false 
}));

app.use(flash());
app.use('/', authenticated);

app.use(function(req, res, next){
    if(req.session.user){
        next();
    }else{
        return res.redirect('/logout');
    }
});



app.use('/users', users);
app.use('/convention', convention);
app.use('/patient', patient);
app.use('/produit', produit);
app.use('/espace', espacePatient);




app.get('/', (req, res)=>{
    if(req.session.user.droit=='caissier'){
        return res.redirect('/patient/list/CREATE');
    }

    if(req.session.user.droit=='admin'){
        return res.redirect('/users/list/CREATE');
    }
    
});

app.get('/compta', (req, res, next) => {
    if(req.session.user.droit=='admin'){
        next();
    }else{
        res.send("<h1>VOUS N'AVEZ PAS LE DROIT D'ACCES A CETTE PAGE</h1>");
    }
  });
app.get('/compta', async function(req, res){
    var rs= await indexSerivce.comptabilite();

    return res.render('traitement/compta',{
        compta: rs
    })
});



app.get('*', function(req, res){
    res.send('<h1>404 PAGE NOT FOUND</h1>')
});
app.listen(3000, ()=>{
    console.log('App listen at port 3000');
})
