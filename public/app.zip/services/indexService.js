const pool=require('./provider');

var comptabilite = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select type, sum(montant_total_convention) as montant_convention, sum(montant_total_patient) as montant_patient from v_facture group by type',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

module.exports={
comptabilite
};