const pool=require('./provider');

var list = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from produit',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}


const add = (produit) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "insert into produit (intitule, prix_sans_convention, prix_avec_convention, type, who_done, when_done) values ($1,$2,$3,$4,$5,$6)",
            [produit.intitule, produit.prix_sans_convention, produit.prix_avec_convention, produit.type, produit.who_done, produit.when_done],    
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


const edit = (produit) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "update produit set intitule=$2, prix_sans_convention=$3, prix_avec_convention=$4, type=$5, who_done=$6, when_done=$7 where id=$1",
            [produit.id, produit.intitule, produit.prix_sans_convention, produit.prix_avec_convention, produit.type, produit.who_done, produit.when_done],    
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}

const mapProduit = (intitule, prix_sans_convention, prix_avec_convention, type, who_done, when_done) => {
      var produit={
        intitule: intitule, 
        prix_sans_convention: prix_sans_convention, 
        prix_avec_convention: prix_avec_convention, 
        type: type, 
        who_done: who_done, 
        when_done: when_done
    }
    return produit;
}

const isProduitExist=async (intitule)=>{
    var produits =await list();
    return produits.filter(u=>u.intitule==intitule).length;
}

const getById=async (id)=>{
    var produit =await list();
    return produit.filter(u=>u.id==id);
}

module.exports={
    list,
    add,
    edit,
    isProduitExist,
    mapProduit,
    getById
};