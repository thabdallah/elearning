const Pool=require('pg').Pool;

const pool=new Pool({
user: 'postgres',
password: 'pass',
database: 'kln',
host: 'localhost',
port: 5432
});
pool.connect();

module.exports=pool;