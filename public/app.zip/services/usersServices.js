const pool=require('./provider');

var list = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from users',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}


const add = (user) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "insert into users (login, nom_prenom, droit, telephone, who_done, when_done,etat, type_medecin) values ($1,$2,$3,$4,$5,$6,$7, $8)",
            [user.login, user.nom_prenom, user.droit, user.telephone, user.who_done, user.when_done, true, user.type_medecin],    
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


const edit = (user) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "update users set nom_prenom=$1, droit=$2, telephone=$3, who_done=$4, when_done=$5, type_medecin=$7 where login=$6",
            [ user.nom_prenom, user.droit, user.telephone, user.who_done, user.when_done, user.login, user.type_medecin],
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}

const init = (login) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'update users set passe=$1 where login=$2',
             ["1234", login],            
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


const setEtat = (login) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'update users set etat=not etat where login=$1',
             [login],            
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}



const mapUser = (nom_prenom, login, droit, telephone, type_medecin) => {
      var user={
        nom_prenom: nom_prenom,
        login: login,
        droit: droit,
        telephone: telephone,
        type_medecin: type_medecin
    }
    return user;
}

const isUserExist=async (login)=>{
    var users =await list();
    return users.filter(u=>u.login==login).length;
}

const getByLogin=async (login)=>{
    var user =await list();
    return user.filter(u=>u.login==login);
}


const isUserCanLogin=  async (login, password)=>{
    var users= await list();
    return users.filter(u=>(u.login==login && u.passe==password && u.etat==true));
}


const changePassword = (login, pass) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'update users set passe=$1 where login=$2',
             [pass, login],            
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}




module.exports={
    isUserCanLogin,
    getByLogin,
    isUserExist,
    mapUser,
    setEtat,
    init,
    edit,
    add,
    list,
    changePassword
};