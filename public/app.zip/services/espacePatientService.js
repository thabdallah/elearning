const pool=require('./provider');

var getPatientById = (id) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from patient where id=$1',
             [id],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getConventionById = (id) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from convention where id=$1',
             [id],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getProduitById = (id) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from produit where id=$1',
             [id],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getPatientById = (id) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from patient where id=$1',
             [id],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getAllConsultation = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from produit where type=$1',
             ["CONSULTATION"],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getAllOtherProduit = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from produit where type<>$1',
             ["CONSULTATION"],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getAllMedecin = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from users where droit=$1',
             ["medecin"],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getConvention = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from convention order by id desc',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getTempConsultationByPatient = (idPatient) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from operation_temp  where patient=$1 and type_operation=$2 and id not in (select id from operation)',
             [idPatient, 'CONSULTATION'],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}


var getTempAutresServiceByPatient = (idPatient) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from operation_temp  where patient=$1 and type_operation<>$2 and id not in (select id from operation)',
             [idPatient, 'CONSULTATION'],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}





var getFactureByPatient = (idPatient) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from v_facture  where patient=$1 order by idfacture desc',
             [idPatient],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}



var save = (patient, produit, medecin, convention, numero_carnet, autre_info_convention, who_done, when_done,quantite,couverture,montant_operation,montant_convention,montant_patient,montant_total_operation,montant_total_convention,montant_total_patient,type_operation,intituleProd,intitule_convention) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'insert into operation_temp (patient, produit, medecin, convention, numero_carnet, autre_info_convention, who_done, when_done,quantite,couverture,montant_operation,montant_convention,montant_patient,montant_total_operation,montant_total_convention,montant_total_patient,type_operation,intitule_produit,intitule_convention) values ($1, $2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)',
             [patient, produit, medecin, convention, numero_carnet, autre_info_convention, who_done, when_done,quantite,couverture,montant_operation,montant_convention,montant_patient,montant_total_operation,montant_total_convention,montant_total_patient,type_operation,intituleProd,intitule_convention],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


var validerOperationn = (type, patient) => {
    var req="";
    if(type=='CONSULTATION'){
        req='insert into operation select * from operation_temp where type_operation=$1 and patient=$2 and id not in (select id from operation)';
    }else{
        req='insert into operation select * from operation_temp where type_operation<>$1 and patient=$2 and id not in (select id from operation)';
    }
    type='CONSULTATION';
    return new Promise(function(resolve, reject) {
        pool.query(
             req,
             [type, patient],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


var supprimerOp = (idOperation) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'delete from operation_temp where id=$1',
             [idOperation],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}

var createFacture = (mOp, mConv, mPatient, mLettre, who_done, when_done) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'INSERT INTO public.facture(montant_total_operation, montant_total_convention, montant_total_patient, montant_lettre, who_done, when_done)VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
             [mOp, mConv, mPatient, mLettre, who_done, when_done],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


async function  validerOperation (who_done, when_done, type, patient) {

    const db = await pool.connect();


    var req="";
    var reqUpdate="";
    var reqSelect="";
    if(type=='CONSULTATION'){
        req='insert into operation select * from operation_temp where type_operation=$1 and patient=$2 and id not in (select id from operation)';
        reqUpdate='update  operation_temp set facture=$3 where type_operation=$1 and patient=$2 and id not in (select id from operation)';
        reqSelect='select * from operation_temp where type_operation=$1 and patient=$2 and id not in (select id from operation)';
    }else{
        req='insert into operation select * from operation_temp where type_operation<>$1 and patient=$2 and id not in (select id from operation)';
        reqUpdate='update  operation_temp set facture=$3 where type_operation<>$1 and patient=$2 and id not in (select id from operation)';
        reqSelect='select * from operation_temp where type_operation<>$1 and patient=$2 and id not in (select id from operation)';
    }
    type='CONSULTATION';

    var reqFacture='INSERT INTO public.facture(montant_total_operation, montant_total_convention, montant_total_patient, montant_lettre, who_done, when_done)VALUES ($1, $2, $3, $4, $5, $6) RETURNING id';


    try {
        await db.query('BEGIN')


        const getLines=reqSelect;
        const getLinesValue=[type, patient];
        var rs5=await db.query(getLines, getLinesValue);

        mOp=getMontantTotalOperation(rs5.rows); 
        mConv=getMontantTotalConvention(rs5.rows); 
        mPatient=getMontantTotalPatient(rs5.rows); 
        mLettre='test';

        const insertFacture=reqFacture;
        const insertFactureValue=[mOp, mConv, mPatient, mLettre, who_done, when_done];
        var rs=await db.query(insertFacture, insertFactureValue);
        var idFacture=rs.rows.shift().id;
        /*console.log('4');
        console.log('-----------------------------------------------');
        console.log(rs);
        console.log('-----------------------------------------------');
*/
        const updateOp=reqUpdate;
        const updateOpValue=[type, patient, idFacture];
        var rs2=await db.query(updateOp, updateOpValue);
/*
        console.log('******************************************');
        console.log(rs2);
        console.log('******************************************');
*/
        const insertOp=req;
        const insertOpValue=[type, patient];
        var rs3=await db.query(insertOp, insertOpValue);

        /*console.log('++++++++++++++++++++++++++++++++++++++++++++');
        console.log(rs3);
        console.log('++++++++++++++++++++++++++++++++++++++++++++');
*/
        await db.query('COMMIT')
        return 1;
      } catch (e) {
        //console.log('5');
        //console.log(e);
        await db.query('ROLLBACK')
        return 0;
        throw e
      } finally {
        //console.log('6');
        db.release()
      }
    //})().catch(e => console.error(e.stack))
}

function getMontantTotalOperation(lignes){
    var total=0;
    for (let index = 0; index < lignes.length; index++) {
        total = parseInt(total) + parseInt(lignes[index].montant_total_operation);
    }
    return total;
}

function getMontantTotalConvention(lignes){
    var total=0;
    for (let index = 0; index < lignes.length; index++) {
        total = parseInt(total) + parseInt(lignes[index].montant_total_convention);
    }
    return total;
}

function getMontantTotalPatient(lignes){
    var total=0;
    for (let index = 0; index < lignes.length; index++) {
        total = parseInt(total) + parseInt(lignes[index].montant_total_patient);
    }
    return total;
}


module.exports={
    getPatientById,
    getConvention,
    getAllMedecin,
    getAllConsultation,
    save,
    getConventionById,
    getProduitById,
    getTempConsultationByPatient,
    validerOperation,
    supprimerOp,
    getAllOtherProduit,
    getTempAutresServiceByPatient,
    createFacture,
    getFactureByPatient
};