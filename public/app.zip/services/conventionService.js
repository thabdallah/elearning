const pool=require('./provider');

var list = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from convention',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}


const add = (convention) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "insert into convention (intitule, couverture_consultation, couverture_produit, couverture_examen, couverture_soins, couverture_hospitalisation, who_done, when_done) values ($1,$2,$3,$4,$5,$6,$7,$8)",
            [convention.intitule, convention.couverture_consultation, convention.couverture_produit, convention.couverture_examen, convention.couverture_soins, convention.couverture_hospitalisation,convention.who_done, convention.when_done],    
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


const edit = (convention) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "update convention set couverture_consultation=$2, couverture_produit=$3, couverture_examen=$4, couverture_soins=$5, couverture_hospitalisation=$6, who_done=$7, when_done=$8 where intitule=$1",
            [convention.intitule, convention.couverture_consultation, convention.couverture_produit, convention.couverture_examen, convention.couverture_soins, convention.couverture_hospitalisation,convention.who_done, convention.when_done],    
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}

const mapConvention = (intitule, couverture_consultation, couverture_produit, couverture_examen, couverture_soins, couverture_hospitalisation) => {
      var convention={
        intitule: intitule,
        couverture_consultation: couverture_consultation,
        couverture_produit: couverture_produit, 
        couverture_examen: couverture_examen,
        couverture_soins: couverture_soins,
        couverture_hospitalisation: couverture_hospitalisation
    }
    return convention;
}

const isConventionExist=async (intitule)=>{
    var conventions =await list();
    return conventions.filter(u=>u.intitule==intitule).length;
}

const getByIntitule=async (intitule)=>{
    var convention =await list();
    return convention.filter(u=>u.intitule==intitule);
}

module.exports={
    list,
    add,
    edit,
    isConventionExist,
    mapConvention,
    getByIntitule
};