const pool=require('./provider');

var list = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from patient',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}


const add = (patient) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "insert into patient (nom_prenom, telephone, adresse, situation, age, who_done, when_done, deleted, sexe) values ($1,$2,$3,$4,$5,$6,$7,$8,$9)",
            [patient.nom_prenom, patient.telephone, patient.adresse, patient.situation, patient.age, patient.who_done, patient.when_done, false, patient.sexe],    
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}


const edit = (patient) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            "update patient set nom_prenom=$2, telephone=$3, adresse=$4, situation=$5, age=$6, who_done=$7, when_done=$8, sexe=$9 where id=$1",
            [patient.id,patient.nom_prenom, patient.telephone, patient.adresse, patient.situation, patient.age, patient.who_done, patient.when_done, patient.sexe],    
            (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results);
        })
    })
}

const mapPatient = (nom_prenom, telephone, adresse, situation, age, sexe) => {
      var patient={
        nom_prenom: nom_prenom,
        telephone: telephone,
        adresse: adresse, 
        situation: situation, 
        age: age, 
        sexe: sexe
    }
    return patient;
}

const isPatientExist=async (telephone)=>{
    var patients =await list();
    return patients.filter(u=>u.telephone==telephone).length;
}

const getById=async (id)=>{
    var patient =await list();
    return patient.filter(u=>u.id==id);
}

var getFacture = () => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from v_facture  order by idfacture desc',
             [],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

var getFactureByUser = (user) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from v_facture where who_done=$1  order by idfacture desc',
             [user],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}

   

var situation = (dd, df, user) => {
    return new Promise(function(resolve, reject) {
        pool.query(
            'select * from v_facture where who_done=$3 and when_done between $1 and $2  order by idfacture desc',
            [dd,df,user],
             (error, results) => {
            if (error) {
                reject(error)
            }
            resolve(results.rows);
        })
    })
}



module.exports={
    list,
    add,
    edit,
    isPatientExist,
    mapPatient,
    getById,
    getFacture,
    getFactureByUser,
    situation
};